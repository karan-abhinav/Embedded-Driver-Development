#include "uart.h"


#define GPIOBEN		(1U<<1)
#define UART3EN		(1U<<18)

#define CR1_TE		(1U<<3)
#define CR1_RE		(1U<<2)
#define CR1_UE		(1U<<13)
#define SR_TXE		(1U<<7)

#define SYS_FREQ	16000000
#define APB1_CLK	SYS_FREQ
#define CR1_RXNEIE	(1U<<5)

#define UART_BAUDRATE	115200

static void uart_set_baudrate(USART_TypeDef *USARTx,uint32_t PeriphClk,uint32_t BaudRate);
static uint16_t compute_uart_bd(uint32_t PeriphClk, uint32_t BaudRate);

void usart3_write(int ch);


int __io_putchar(int ch){

	usart3_write(ch);
	return ch;
}

void uart3_rx_interrupt_init(void){
	/************configure uart gpio pin***********/
	/*Enable clock access to gpiob*/
	RCC->AHB1ENR |= GPIOBEN;
	/*Set PB11 to alternate function mode*/
	GPIOB->MODER &= ~(1U<<20);
	GPIOB->MODER |= (1U<<21);
	/*Set PB10 alternate function type to USART_TX (AF07)*/
	GPIOB->AFR[1] |= (1U<<8);
	GPIOB->AFR[1] |= (1U<<9);
	GPIOB->AFR[1] |= (1U<<10);
	GPIOB->AFR[1] &= ~(1U<<11);

	/*Set PB11 to alternate function mode*/
	GPIOB->MODER &= ~(1U<<22);
	GPIOB->MODER |= (1U<<23);
	/*Set PB11 alternate function type to USART_TX (AF07)*/
	GPIOB->AFR[1] |= (1U<<12);
	GPIOB->AFR[1] |= (1U<<13);
	GPIOB->AFR[1] |= (1U<<14);
	GPIOB->AFR[1] &= ~(1U<<15);
	/************configure usart module***********/
	/*Enable clock access to usart3*/
	RCC->APB1ENR |= UART3EN;

	/*Configure baudrate*/
	uart_set_baudrate(USART3,APB1_CLK, UART_BAUDRATE);

	/*Configure the transfer direction*/
	USART3->CR1 = CR1_TE | CR1_RE;

	/*Enable RXNE interrupt */
	USART3->CR1 |= CR1_RXNEIE;

	/*Enable USART3 in NVIC*/
	NVIC_EnableIRQ(USART3_IRQn);

	/*Enable the usart module*/
	USART3->CR1 |= CR1_UE;
}



void uart3_rxtx_init(void){
	/************configure uart gpio pin***********/
	/*Enable clock access to gpiob*/
	RCC->AHB1ENR |= GPIOBEN;
	/*Set PB11 to alternate function mode*/
	GPIOB->MODER &= ~(1U<<20);
	GPIOB->MODER |= (1U<<21);
	/*Set PB10 alternate function type to USART_TX (AF07)*/
	GPIOB->AFR[1] |= (1U<<8);
	GPIOB->AFR[1] |= (1U<<9);
	GPIOB->AFR[1] |= (1U<<10);
	GPIOB->AFR[1] &= ~(1U<<11);

	/*Set PB11 to alternate function mode*/
	GPIOB->MODER &= ~(1U<<22);
	GPIOB->MODER |= (1U<<23);
	/*Set PB11 alternate function type to USART_TX (AF07)*/
	GPIOB->AFR[1] |= (1U<<12);
	GPIOB->AFR[1] |= (1U<<13);
	GPIOB->AFR[1] |= (1U<<14);
	GPIOB->AFR[1] &= ~(1U<<15);
	/************configure usart module***********/
	/*Enable clock access to usart3*/
	RCC->APB1ENR |= UART3EN;

	/*Configure baudrate*/
	uart_set_baudrate(USART3,APB1_CLK, UART_BAUDRATE);

	/*Configure the transfer direction*/
	USART3->CR1 = CR1_TE | CR1_RE;


	/*Enable the usart module*/
	USART3->CR1 |= CR1_UE;
}
void uart3_tx_init(void){
	/************configure uart gpio pin***********/
	/*Enable clock access to gpiob*/
	RCC->AHB1ENR |= GPIOBEN;
	/*Set PB10 to alternate function mode*/
	GPIOB->MODER &= ~(1U<<20);
	GPIOB->MODER |= (1U<<21);
	/*Set PB10 alternate function type to USART_TX (AF07)*/
	GPIOB->AFR[1] |= (1U<<8);
	GPIOB->AFR[1] |= (1U<<9);
	GPIOB->AFR[1] |= (1U<<10);
	GPIOB->AFR[1] &= ~(1U<<11);
	/************configure usart module***********/
	/*Enable clock access to usart3*/
	RCC->APB1ENR |= UART3EN;

	/*Configure baudrate*/
	uart_set_baudrate(USART3,APB1_CLK, UART_BAUDRATE);

	/*Configure the transfer direction*/
	USART3->CR1 = CR1_TE;

	/*Enable the usart module*/
	USART3->CR1 |= CR1_UE;
}

char usart3_read(void){
	/* Make sure receive data register is not empty */
	while(!(USART3->SR & SR_RXNE)){}

	/*Read Data*/
	return USART3->DR;
}

void usart3_write(int ch){
	/* Make sure transmit data register is empty */
	while(!(USART3->SR & SR_TXE)){}
	/* Write to transmit data register */
	USART3->DR = (ch & 0xFF);
}

static void uart_set_baudrate(USART_TypeDef *USARTx,uint32_t PeriphClk,uint32_t BaudRate){
	USARTx->BRR = compute_uart_bd(PeriphClk,BaudRate);
}

static uint16_t compute_uart_bd(uint32_t PeriphClk, uint32_t BaudRate){
	return ((PeriphClk + (BaudRate/2U))/BaudRate);
}
