

#ifndef UART_H_
#define UART_H_

#include "stm32f4xx.h"
#include <stdint.h>
void uart3_tx_init(void);
void uart3_rxtx_init(void);
char usart3_read(void);
void uart3_rx_interrupt_init(void);
#define SR_RXNE		(1U<<5)
#endif /* UART_H_ */
